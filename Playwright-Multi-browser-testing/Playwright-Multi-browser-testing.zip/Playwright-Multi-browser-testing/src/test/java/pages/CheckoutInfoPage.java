package pages;

import com.microsoft.playwright.Page;

/**
 * CheckoutInfoPage represents the "Checkout: Your Information" form page.
 */
public class CheckoutInfoPage {

    private final Page page;

    private static final String CHECKOUT_TITLE  = ".title";
    private static final String FIRST_NAME_FIELD = "#first-name";
    private static final String LAST_NAME_FIELD  = "#last-name";
    private static final String POSTAL_CODE_FIELD = "#postal-code";
    private static final String CONTINUE_BUTTON  = "#continue";

    public CheckoutInfoPage(Page page) {
        this.page = page;
    }

    /**
     * Returns whether the checkout information page title is visible.
     */
    public boolean isTitleDisplayed() {
        return page.isVisible(CHECKOUT_TITLE);
    }

    /**
     * Fills in the shipping information fields and submits the form.
     *
     * @param firstName  Customer's first name
     * @param lastName   Customer's last name
     * @param postalCode Customer's postal code
     */
    public void fillInformation(String firstName, String lastName, String postalCode) {
        page.fill(FIRST_NAME_FIELD, firstName);   // Fill the first name field
        page.fill(LAST_NAME_FIELD, lastName);     // Fill the last name field
        page.fill(POSTAL_CODE_FIELD, postalCode); // Fill the postal code field
        page.click(CONTINUE_BUTTON);              // Submit the form
    }
}