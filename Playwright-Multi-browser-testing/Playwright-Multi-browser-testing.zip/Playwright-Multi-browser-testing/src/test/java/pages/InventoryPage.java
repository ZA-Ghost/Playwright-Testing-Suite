package pages;

import com.microsoft.playwright.Page;

/**
 * InventoryPage represents the Products listing page shown after login.
 *
 * page.textContent() retrieves the visible text of a matched element.
 * page.click()       clicks the matched element.
 * page.locator()     creates a reusable locator reference.
 */
public class InventoryPage {

    private final Page page;

    private static final String PAGE_TITLE         = ".title";
    private static final String ADD_BACKPACK_BUTTON = "#add-to-cart-sauce-labs-backpack";
    private static final String CART_BADGE          = ".shopping_cart_badge";

    public InventoryPage(Page page) {
        this.page = page;
    }

    /**
     * Returns the page title text (e.g. "Products").
     * Used to confirm the inventory page loaded after login.
     */
    public String getPageTitle() {
        return page.textContent(PAGE_TITLE);
    }

    /**
     * Clicks the Add to Cart button for the Sauce Labs Backpack.
     */
    public void addBackpackToCart() {
        page.click(ADD_BACKPACK_BUTTON);
    }

    /**
     * Returns the cart badge count as a string (e.g. "1").
     * Used to verify the item was added successfully.
     */
    public String getCartBadgeCount() {
        return page.textContent(CART_BADGE);
    }
}