package pages;

import com.microsoft.playwright.Page;

/**
 * ConfirmationPage represents the order confirmation page shown after checkout.
 */
public class ConfirmationPage {

    private final Page page;

    private static final String CONFIRMATION_HEADER = ".complete-header";

    public ConfirmationPage(Page page) {
        this.page = page;
    }

    /**
     * Returns the text of the order confirmation header.
     * Used to assert the expected success message is displayed.
     *
     * @return The confirmation message (e.g. "Thank you for your order!")
     */
    public String getConfirmationText() {
        return page.textContent(CONFIRMATION_HEADER);
    }
}