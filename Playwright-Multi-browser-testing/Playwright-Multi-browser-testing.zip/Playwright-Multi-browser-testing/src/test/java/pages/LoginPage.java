package pages;

import com.microsoft.playwright.Page;

/**
 * LoginPage represents the SauceDemo login screen.
 *
 * Playwright locators use CSS selectors, text selectors, or role-based
 * selectors instead of Selenium's By.id / By.className.
 *
 * page.fill()  — clears the field and types the value in one step
 * page.click() — clicks the matched element
 */
public class LoginPage {

    private final Page page;

    // Playwright CSS selectors for the login form elements
    private static final String USERNAME_FIELD = "#user-name";
    private static final String PASSWORD_FIELD  = "#password";
    private static final String LOGIN_BUTTON    = "#login-button";
    private static final String ERROR_MESSAGE   = "[data-test='error']";

    public LoginPage(Page page) {
        this.page = page;
    }

    /**
     * Fills in the login form and submits it.
     *
     * @param username The username to enter
     * @param password The password to enter
     */
    public void login(String username, String password) {
        page.fill(USERNAME_FIELD, username); // Clear and type the username
        page.fill(PASSWORD_FIELD, password); // Clear and type the password
        page.click(LOGIN_BUTTON);            // Click the login button
    }

    /**
     * Returns the error message text shown when login fails.
     *
     * @return The visible error message string
     */
    public String getErrorMessage() {
        return page.textContent(ERROR_MESSAGE);
    }
}