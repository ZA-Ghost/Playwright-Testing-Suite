package pages;

import com.microsoft.playwright.Page;

/**
 * CartPage represents the shopping cart page (Your Cart).
 *
 * page.isVisible() checks whether an element is present and visible —
 * equivalent to Selenium's WebElement.isDisplayed().
 */
public class CartPage {

    private final Page page;

    private static final String CART_ICON      = "#shopping_cart_container a";
    private static final String CART_TITLE     = ".title";
    private static final String CHECKOUT_BUTTON = "#checkout";

    public CartPage(Page page) {
        this.page = page;
    }

    /**
     * Clicks the cart icon in the navigation bar to open the cart.
     */
    public void openCart() {
        page.click(CART_ICON);
    }

    /**
     * Returns whether the cart page title is visible.
     */
    public boolean isCartTitleDisplayed() {
        return page.isVisible(CART_TITLE);
    }

    /**
     * Clicks the Checkout button to proceed from the cart to the checkout form.
     */
    public void proceedToCheckout() {
        page.click(CHECKOUT_BUTTON);
    }
}