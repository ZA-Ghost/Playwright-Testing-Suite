package tests;

import base.BaseTest;
import com.microsoft.playwright.Page;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.*;

/**
 * OnlineOrderTest validates the complete end-to-end purchase flow on SauceDemo
 * using Playwright instead of Selenium WebDriver.
 *
 * The Page instance comes from BaseTest.getPage() — the ThreadLocal store —
 * so this test class works identically whether it is running on Chromium,
 * Firefox, or WebKit. The browser choice is entirely controlled by the
 * TestNG XML suite parameter, not by anything in this class.
 *
 * Thread.sleep() is replaced by Playwright's built-in waitForLoadState()
 * and the SlowMo option set in BaseTest, which paces every action globally.
 * This is the correct Playwright approach — explicit waits are automatic.
 */
public class OnlineOrderTest extends BaseTest {

    /**
     * Test 1: Verifies that a user can log in with valid credentials.
     * Confirms the Products page title is displayed after login.
     */
    @Test(priority = 1)
    public void testLogin() {
        Page page = getPage();

        // Wait for the login page to be fully ready before interacting
        page.waitForLoadState();

        LoginPage loginPage = new LoginPage(page);
        loginPage.login("standard_user", "secret_sauce");

        // Wait for the inventory page to load after login
        page.waitForLoadState();

        InventoryPage inventoryPage = new InventoryPage(page);
        Assert.assertEquals(inventoryPage.getPageTitle().trim(), "Products",
                "Login failed — Products page title not found.");
    }

    /**
     * Test 2: Verifies that a product can be added to the shopping cart.
     * Confirms the cart badge updates to "1" after adding the backpack.
     */
    @Test(priority = 2)
    public void testAddToCart() {
        Page page = getPage();

        InventoryPage inventoryPage = new InventoryPage(page);
        inventoryPage.addBackpackToCart();

        // waitForSelector blocks until the cart badge appears in the DOM
        page.waitForSelector(".shopping_cart_badge");

        Assert.assertEquals(inventoryPage.getCartBadgeCount().trim(), "1",
                "Cart badge did not update — item may not have been added.");
    }

    /**
     * Test 3: Verifies that clicking the cart icon opens the Cart page.
     * Confirms the "Your Cart" title is visible after navigation.
     */
    @Test(priority = 3)
    public void testGoToCartPage() {
        Page page = getPage();

        CartPage cartPage = new CartPage(page);
        cartPage.openCart();

        // Wait for navigation to the cart page to complete
        page.waitForLoadState();

        Assert.assertTrue(cartPage.isCartTitleDisplayed(),
                "Cart page did not load — title not visible.");
    }

    /**
     * Test 4: Verifies that clicking Checkout opens the checkout information form.
     * Confirms the form page title is visible after clicking Checkout.
     */
    @Test(priority = 4)
    public void testCheckoutStart() {
        Page page = getPage();

        CartPage cartPage = new CartPage(page);
        cartPage.proceedToCheckout();

        page.waitForLoadState();

        CheckoutInfoPage checkoutInfoPage = new CheckoutInfoPage(page);
        Assert.assertTrue(checkoutInfoPage.isTitleDisplayed(),
                "Checkout information page did not load.");
    }

    /**
     * Test 5: Verifies that customer information can be submitted on the checkout form.
     * Confirms the order overview page is displayed after form submission.
     */
    @Test(priority = 5)
    public void testCheckoutInformation() {
        Page page = getPage();

        CheckoutInfoPage checkoutInfoPage = new CheckoutInfoPage(page);
        checkoutInfoPage.fillInformation("Khwezi", "Test", "1234");

        page.waitForLoadState();

        CheckoutOverviewPage overviewPage = new CheckoutOverviewPage(page);
        Assert.assertTrue(overviewPage.isTitleDisplayed(),
                "Checkout overview page did not load after submitting information.");
    }

    /**
     * Test 6: Verifies that the order can be successfully completed.
     * Confirms the "Thank you for your order!" confirmation message is displayed.
     */
    @Test(priority = 6)
    public void testFinishCheckout() {
        Page page = getPage();

        CheckoutOverviewPage overviewPage = new CheckoutOverviewPage(page);
        overviewPage.finishOrder();

        page.waitForLoadState();

        ConfirmationPage confirmationPage = new ConfirmationPage(page);
        Assert.assertEquals(confirmationPage.getConfirmationText().trim(),
                "Thank you for your order!",
                "Order confirmation message not displayed — checkout may have failed.");
    }
}