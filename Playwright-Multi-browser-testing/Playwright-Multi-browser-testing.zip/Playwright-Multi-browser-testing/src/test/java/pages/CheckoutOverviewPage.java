package pages;

import com.microsoft.playwright.Page;

/**
 * CheckoutOverviewPage represents the "Checkout: Overview" order summary page.
 */
public class CheckoutOverviewPage {

    private final Page page;

    private static final String OVERVIEW_TITLE = ".title";
    private static final String FINISH_BUTTON  = "#finish";

    public CheckoutOverviewPage(Page page) {
        this.page = page;
    }

    /**
     * Returns whether the overview page title is visible.
     */
    public boolean isTitleDisplayed() {
        return page.isVisible(OVERVIEW_TITLE);
    }

    /**
     * Clicks the Finish button to place the order.
     */
    public void finishOrder() {
        page.click(FINISH_BUTTON);
    }
}