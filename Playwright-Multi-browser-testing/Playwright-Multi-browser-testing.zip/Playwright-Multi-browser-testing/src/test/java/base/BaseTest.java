package base;

import com.microsoft.playwright.*;
import org.testng.annotations.*;

/**
 * BaseTest is the parent class for all Playwright test classes.
 *
 * Playwright's object hierarchy is:
 *   Playwright → BrowserType → Browser → BrowserContext → Page
 *
 * Each layer is created fresh per test class and torn down afterwards.
 * ThreadLocal<Page> ensures that when tests run in parallel across browsers,
 * each thread works with its own isolated Page — they never share state.
 *
 * The browser type (chromium / firefox / webkit) is injected from the
 * TestNG XML suite file via @Parameters so no code changes are needed
 * to switch or add browsers.
 */
public class BaseTest {

    /*
     * ThreadLocal stores one Page per thread.
     * When testng-all-browsers.xml runs all three browsers in parallel,
     * each browser runs in its own thread — ThreadLocal prevents them
     * from overwriting each other's Page reference.
     */
    private static final ThreadLocal<Page> pageThreadLocal = new ThreadLocal<>();

    // Playwright instance — one per test class lifecycle
    private Playwright playwright;

    // The open browser session
    private Browser browser;

    /**
     * Returns the Page instance for the current thread.
     * Called by every page class and test method to interact with the browser.
     *
     * @return The active Playwright Page for this thread
     */
    public static Page getPage() {
        return pageThreadLocal.get();
    }

    /**
     * Runs once before any tests in this class execute.
     *
     * Reads the "browser" parameter from the TestNG XML suite,
     * launches the correct browser, opens a new context and page,
     * and navigates to SauceDemo.
     *
     * BrowserContext is Playwright's equivalent of a fresh browser profile —
     * cookies, storage, and sessions are completely isolated per context.
     *
     * @param browserName The browser to launch: "chromium", "firefox", or "webkit"
     */
    @BeforeClass
    @Parameters("browser")
    public void setUp(@Optional("chromium") String browserName) throws InterruptedException {

        // Create the Playwright engine — this is the entry point for everything
        playwright = Playwright.create();

        // Select and launch the correct browser type based on the XML parameter
        switch (browserName.toLowerCase()) {

            case "firefox":
                browser = playwright.firefox().launch(
                        new BrowserType.LaunchOptions()
                                .setHeadless(false)   // Run with a visible browser window
                                .setSlowMo(80)        // Slow each action by 80ms so execution is clearly visible
                );
                break;

            case "webkit":
                browser = playwright.webkit().launch(
                        new BrowserType.LaunchOptions()
                                .setHeadless(false)   // Run with a visible browser window
                                .setSlowMo(80)        // Slow each action by 80ms so execution is clearly visible
                );
                break;

            case "chromium":
            default:
                browser = playwright.chromium().launch(
                        new BrowserType.LaunchOptions()
                                .setHeadless(false)   // Run with a visible browser window
                                .setSlowMo(80)        // Slow each action by 80ms so execution is clearly visible
                );
                break;
        }

        // Create a fresh browser context — isolated cookies, cache, and session storage
        BrowserContext context = browser.newContext(
                new Browser.NewContextOptions()
                        .setViewportSize(1280, 800) // Set a consistent viewport across all browsers
        );

        // Open a new page (tab) inside the context
        Page page = context.newPage();

        // Store this page in ThreadLocal so all tests in this thread use the same page
        pageThreadLocal.set(page);

        // Navigate to the application under test
        page.navigate("https://www.saucedemo.com/");

        Thread.sleep(1500); // Let the login page fully render before any test begins
    }

    /**
     * Runs once after all tests in this class have completed.
     * Closes the browser and shuts down the Playwright engine to free resources.
     */
    @AfterClass
    public void tearDown() {
        Page page = pageThreadLocal.get();

        if (page != null) {
            page.context().close(); // Close the browser context (and the page inside it)
            pageThreadLocal.remove(); // Clean up the ThreadLocal reference
        }

        if (browser != null) {
            browser.close(); // Close the browser process
        }

        if (playwright != null) {
            playwright.close(); // Shut down the Playwright engine
        }
    }
}