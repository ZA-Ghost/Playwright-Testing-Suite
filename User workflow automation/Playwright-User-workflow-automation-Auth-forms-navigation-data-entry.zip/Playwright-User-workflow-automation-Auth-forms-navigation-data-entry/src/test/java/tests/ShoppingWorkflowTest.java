package tests;

import base.BaseTest;
import com.microsoft.playwright.Page;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import workflows.AuthWorkflow;
import workflows.NavigationWorkflow;
import workflows.ShoppingWorkflow;

/**
 * ShoppingWorkflowTest validates product browsing and cart management.
 *
 * Tests cover:
 *   - The inventory page loading correctly after login
 *   - Adding a single item to the cart
 *   - Adding multiple items and verifying the cart count
 *   - Navigating to the cart and confirming arrival
 *
 * @BeforeClass logs in once before all tests in this class run,
 * establishing the authenticated session that shopping tests require.
 */
public class ShoppingWorkflowTest extends BaseTest {

    /**
     * Logs in as the standard user before the shopping tests begin.
     * All tests in this class depend on an active authenticated session.
     */
    @BeforeClass(dependsOnMethods = "setUp")
    public void login() {
        AuthWorkflow auth = new AuthWorkflow(getPage());
        auth.loginAsStandardUser();
    }

    /**
     * Test 1: Verifies the inventory page loads with the product grid visible.
     */
    @Test(priority = 1)
    public void testInventoryLoads() {
        ShoppingWorkflow shopping = new ShoppingWorkflow(getPage());

        Assert.assertTrue(shopping.isInventoryLoaded(),
                "Inventory product grid was not visible after login.");
        Assert.assertEquals(shopping.getPageTitle(), "Products",
                "Page title did not read 'Products'.");
    }

    /**
     * Test 2: Verifies that a single item can be added to the cart.
     * Asserts the cart badge updates to "1".
     */
    @Test(priority = 2)
    public void testAddSingleItemToCart() {
        Page page = getPage();
        NavigationWorkflow nav = new NavigationWorkflow(page);
        ShoppingWorkflow shopping = new ShoppingWorkflow(page);

        nav.goToInventory();           // Navigate to the product list
        shopping.addBackpackToCart();  // Add the Sauce Labs Backpack

        Assert.assertEquals(shopping.getCartCount(), "1",
                "Cart badge did not update to 1 after adding one item.");
    }

    /**
     * Test 3: Verifies that multiple items can be added and the cart count is accurate.
     * Navigates to inventory fresh to reset the cart state, then adds three items.
     */
    @Test(priority = 3)
    public void testAddMultipleItemsToCart() {
        Page page = getPage();
        NavigationWorkflow nav = new NavigationWorkflow(page);
        ShoppingWorkflow shopping = new ShoppingWorkflow(page);

        nav.goToInventory();
        shopping.addMultipleItemsToCart(); // Add backpack, bike light, and bolt t-shirt

        Assert.assertEquals(shopping.getCartCount(), "3",
                "Cart badge did not update to 3 after adding three items.");
    }

    /**
     * Test 4: Verifies that clicking the cart icon navigates to the cart page.
     */
    @Test(priority = 4)
    public void testNavigateToCart() {
        Page page = getPage();
        NavigationWorkflow nav = new NavigationWorkflow(page);

        nav.goToCart(); // Click the cart icon in the nav bar

        Assert.assertTrue(page.url().contains("cart"),
                "Clicking the cart icon did not navigate to the cart page.");
        Assert.assertEquals(nav.getCurrentPageTitle(), "Your Cart",
                "Cart page title was not 'Your Cart'.");
    }
}