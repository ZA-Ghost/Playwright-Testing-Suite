package tests;

import base.BaseTest;
import com.microsoft.playwright.Page;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import workflows.AuthWorkflow;
import workflows.CheckoutWorkflow;
import workflows.NavigationWorkflow;
import workflows.ShoppingWorkflow;

/**
 * CheckoutWorkflowTest validates the complete checkout journey step by step.
 *
 * Tests cover:
 *   - Opening the cart after adding an item
 *   - Proceeding to the checkout information form
 *   - Filling in and submitting customer details
 *   - Completing the order and verifying the confirmation message
 *
 * @BeforeClass logs in and adds an item to the cart before the
 * checkout tests begin, establishing the state they depend on.
 */
public class CheckoutWorkflowTest extends BaseTest {

    /**
     * Logs in and adds a product to the cart before checkout tests run.
     * Tests in this class all depend on having an item in the cart.
     */
    @BeforeClass(dependsOnMethods = "setUp")
    public void loginAndAddItem() {
        Page page = getPage();
        AuthWorkflow auth = new AuthWorkflow(page);
        ShoppingWorkflow shopping = new ShoppingWorkflow(page);

        auth.loginAsStandardUser();  // Establish an authenticated session
        shopping.addBackpackToCart(); // Add one item so the cart is not empty
    }

    /**
     * Test 1: Verifies the cart page opens and the correct title is displayed.
     */
    @Test(priority = 1)
    public void testOpenCart() {
        Page page = getPage();
        CheckoutWorkflow checkout = new CheckoutWorkflow(page);
        NavigationWorkflow nav = new NavigationWorkflow(page);

        checkout.openCart();

        Assert.assertTrue(page.url().contains("cart"),
                "Cart page did not open after clicking the cart icon.");
        Assert.assertEquals(nav.getCurrentPageTitle(), "Your Cart",
                "Cart page title was not 'Your Cart'.");
    }

    /**
     * Test 2: Verifies clicking Checkout opens the information form.
     */
    @Test(priority = 2)
    public void testProceedToCheckout() {
        Page page = getPage();
        CheckoutWorkflow checkout = new CheckoutWorkflow(page);
        NavigationWorkflow nav = new NavigationWorkflow(page);

        checkout.proceedToCheckout();

        Assert.assertTrue(page.url().contains("checkout-step-one"),
                "Checkout information page did not load.");
        Assert.assertEquals(nav.getCurrentPageTitle(), "Checkout: Your Information",
                "Checkout information page title was incorrect.");
    }

    /**
     * Test 3: Verifies the checkout form can be filled and submitted.
     * Asserts the order overview page is displayed after submission.
     */
    @Test(priority = 3)
    public void testFillCheckoutInformation() {
        Page page = getPage();
        CheckoutWorkflow checkout = new CheckoutWorkflow(page);
        NavigationWorkflow nav = new NavigationWorkflow(page);

        checkout.fillCheckoutInformation(); // Uses shared UserData constants

        Assert.assertTrue(page.url().contains("checkout-step-two"),
                "Order overview page did not load after submitting information.");
        Assert.assertEquals(nav.getCurrentPageTitle(), "Checkout: Overview",
                "Overview page title was incorrect.");
    }

    /**
     * Test 4: Verifies the order can be completed and the confirmation is shown.
     * Clicks Finish and asserts the thank-you message is displayed.
     */
    @Test(priority = 4)
    public void testFinishOrder() {
        Page page = getPage();
        CheckoutWorkflow checkout = new CheckoutWorkflow(page);

        checkout.finishOrder();

        Assert.assertEquals(checkout.getConfirmationMessage(), "Thank you for your order!",
                "Order confirmation message was not displayed after finishing checkout.");
    }
}