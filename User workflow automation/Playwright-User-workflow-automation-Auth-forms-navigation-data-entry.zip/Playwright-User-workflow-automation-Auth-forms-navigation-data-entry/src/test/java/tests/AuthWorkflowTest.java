package tests;

import base.BaseTest;
import com.microsoft.playwright.Page;
import data.UserData;
import org.testng.Assert;
import org.testng.annotations.Test;
import workflows.AuthWorkflow;

/**
 * AuthWorkflowTest validates all authentication scenarios.
 *
 * Tests cover:
 *   - Successful login with valid credentials
 *   - Failed login with an incorrect password
 *   - Failed login with a locked-out account
 *   - Logout and return to the login page
 *
 * Each test navigates to the login page fresh via the workflow,
 * so tests are independent of each other and can run in any order.
 */
public class AuthWorkflowTest extends BaseTest {

    /**
     * Test 1: Standard user logs in successfully.
     * Asserts the Products page URL is reached after login.
     */
    @Test(priority = 1)
    public void testValidLogin() {
        Page page = getPage();
        AuthWorkflow auth = new AuthWorkflow(page);

        auth.loginAsStandardUser();

        Assert.assertTrue(page.url().contains("inventory"),
                "Valid login did not navigate to the inventory page.");
    }

    /**
     * Test 2: Login fails with an incorrect password.
     * Asserts the credential mismatch error message is shown.
     */
    @Test(priority = 2)
    public void testInvalidPassword() {
        Page page = getPage();
        AuthWorkflow auth = new AuthWorkflow(page);

        auth.loginWithInvalidPassword();

        Assert.assertTrue(auth.getLoginError().contains("Username and password do not match"),
                "Expected credential mismatch error was not displayed.");
    }

    /**
     * Test 3: Locked-out user cannot log in.
     * Asserts the locked-out error message is shown.
     */
    @Test(priority = 3)
    public void testLockedOutUser() {
        Page page = getPage();
        AuthWorkflow auth = new AuthWorkflow(page);

        auth.loginAsLockedOutUser();

        Assert.assertTrue(auth.getLoginError().contains("Sorry, this user has been locked out"),
                "Expected locked-out error message was not displayed.");
    }

    /**
     * Test 4: User can log out successfully.
     * Logs in first, then logs out, and asserts the login page URL is restored.
     */
    @Test(priority = 4)
    public void testLogout() {
        Page page = getPage();
        AuthWorkflow auth = new AuthWorkflow(page);

        auth.loginAsStandardUser(); // Establish an authenticated session first
        auth.logout();              // Open the menu and click Sign Out

        Assert.assertEquals(page.url(), UserData.BASE_URL,
                "Logout did not return to the login page.");
    }
}