package data;

/**
 * UserData is a central store of all test credentials and form data
 * used across workflow and test classes.
 *
 * Keeping data here means that if SauceDemo credentials or form values
 * change, there is exactly one file to update — not scattered strings
 * across every test and workflow class.
 *
 * Constants are grouped by their purpose:
 *   - AUTH:     Login credentials for each account type
 *   - CHECKOUT: Shipping form values used during checkout
 *   - URLS:     Application entry points
 */
public class UserData {

    // ── Auth credentials ───────────────────────────────────────────────────

    /** Standard user — full access, all flows work as expected */
    public static final String STANDARD_USER     = "standard_user";

    /** Locked-out user — login should be rejected with an error message */
    public static final String LOCKED_OUT_USER   = "locked_out_user";

    /** Problem user — UI rendering issues, used for negative testing */
    public static final String PROBLEM_USER      = "problem_user";

    /** Password shared by all SauceDemo test accounts */
    public static final String VALID_PASSWORD    = "secret_sauce";

    /** A password that does not match any account — for negative login tests */
    public static final String INVALID_PASSWORD  = "wrong_password_123";

    // ── Checkout form data ─────────────────────────────────────────────────

    public static final String FIRST_NAME   = "Khwezi";
    public static final String LAST_NAME    = "Test";
    public static final String POSTAL_CODE  = "1234";

    // ── Application URLs ───────────────────────────────────────────────────

    public static final String BASE_URL       = "https://www.saucedemo.com/";
    public static final String INVENTORY_URL  = "https://www.saucedemo.com/inventory.html";
    public static final String CART_URL       = "https://www.saucedemo.com/cart.html";

    // Private constructor — this class is a constants holder, not instantiated
    private UserData() {}
}