package base;

import com.microsoft.playwright.*;
import org.testng.annotations.*;

/**
 * BaseTest is the parent class for all Playwright test classes.
 *
 * Manages the full Playwright lifecycle:
 *   Playwright → Browser → BrowserContext → Page
 *
 * ThreadLocal<Page> ensures each parallel browser run gets its own
 * isolated Page instance — threads never share state.
 *
 * The browser type is injected from the TestNG XML suite via @Parameters.
 * SlowMo is set to 60ms globally so every action is clearly visible
 * without needing Thread.sleep() in individual tests.
 */
public class BaseTest {

    /*
     * ThreadLocal stores one Page per thread.
     * When all three browsers run in parallel each gets its own Page —
     * they cannot interfere with each other.
     */
    private static final ThreadLocal<Page> pageThreadLocal = new ThreadLocal<>();

    private Playwright playwright;
    private Browser browser;

    /**
     * Returns the Page for the current thread.
     * Used by all page classes and workflow classes.
     */
    public static Page getPage() {
        return pageThreadLocal.get();
    }

    /**
     * Runs once before any tests in this class execute.
     *
     * Launches the browser specified in the TestNG XML parameter,
     * creates an isolated BrowserContext, opens a Page,
     * and navigates to SauceDemo.
     *
     * @param browserName "chromium", "firefox", or "webkit"
     */
    @BeforeClass
    @Parameters("browser")
    public void setUp(@Optional("chromium") String browserName) {

        playwright = Playwright.create();

        // Build shared launch options — headless off, slowMo for visibility
        BrowserType.LaunchOptions launchOptions = new BrowserType.LaunchOptions()
                .setHeadless(false) // Show the browser window during execution
                .setSlowMo(60);     // Pause 60ms between every Playwright action globally

        // Launch the correct browser based on the XML parameter
        switch (browserName.toLowerCase()) {
            case "firefox" -> browser = playwright.firefox().launch(launchOptions);
            case "webkit"  -> browser = playwright.webkit().launch(launchOptions);
            default        -> browser = playwright.chromium().launch(launchOptions);
        }

        // Create an isolated browser context — fresh cookies, storage, and session
        BrowserContext context = browser.newContext(
                new Browser.NewContextOptions()
                        .setViewportSize(1366, 768) // Consistent viewport across all browsers
        );

        // Open a new page tab inside the context
        Page page = context.newPage();
        pageThreadLocal.set(page);

        // Navigate to the application under test
        page.navigate("https://www.saucedemo.com/");
        page.waitForLoadState(); // Wait for the page to be fully loaded before any test runs
    }

    /**
     * Runs once after all tests in this class have completed.
     * Closes the page context, browser, and Playwright engine.
     */
    @AfterClass
    public void tearDown() {
        Page page = pageThreadLocal.get();
        if (page != null) {
            page.context().close();
            pageThreadLocal.remove();
        }
        if (browser  != null) browser.close();
        if (playwright != null) playwright.close();
    }
}