package workflows;

import com.microsoft.playwright.Page;
import data.UserData;
import pages.*;

/**
 * CheckoutWorkflow encapsulates all steps of the checkout journey.
 *
 * Covers: opening the cart, proceeding to checkout, filling the
 * information form, finishing the order, and reading the result.
 *
 * Individual step methods allow tests to assert at each stage.
 * The completeFullCheckout() method chains all steps together for
 * tests that only care about the final outcome.
 */
public class CheckoutWorkflow {

    private final Page page;
    private final CartPage cartPage;
    private final CheckoutInfoPage checkoutInfoPage;
    private final CheckoutOverviewPage checkoutOverviewPage;
    private final ConfirmationPage confirmationPage;

    public CheckoutWorkflow(Page page) {
        this.page = page;
        this.cartPage             = new CartPage(page);
        this.checkoutInfoPage     = new CheckoutInfoPage(page);
        this.checkoutOverviewPage = new CheckoutOverviewPage(page);
        this.confirmationPage     = new ConfirmationPage(page);
    }

    /**
     * Clicks the cart icon to open the cart page and waits for it to load.
     */
    public void openCart() {
        cartPage.openCart();
        page.waitForLoadState();
        page.waitForSelector(".cart_list"); // Wait for cart contents to render
    }

    /**
     * Clicks the Checkout button on the cart page.
     * Waits for the information form to be visible before returning.
     */
    public void proceedToCheckout() {
        cartPage.proceedToCheckout();
        page.waitForLoadState();
        page.waitForSelector("#first-name"); // Wait for the form field to be ready
    }

    /**
     * Fills in the checkout information form using the shared UserData constants
     * and clicks Continue to proceed to the order overview.
     */
    public void fillCheckoutInformation() {
        checkoutInfoPage.fillInformation(
                UserData.FIRST_NAME,
                UserData.LAST_NAME,
                UserData.POSTAL_CODE
        );
        page.waitForLoadState();
        page.waitForSelector(".summary_info"); // Wait for the order summary to appear
    }

    /**
     * Fills in the checkout form with custom data values.
     * Used when a test needs to verify form validation with specific inputs.
     *
     * @param firstName  Customer first name to enter
     * @param lastName   Customer last name to enter
     * @param postalCode Postal code to enter
     */
    public void fillCheckoutInformation(String firstName, String lastName, String postalCode) {
        checkoutInfoPage.fillInformation(firstName, lastName, postalCode);
        page.waitForLoadState();
    }

    /**
     * Clicks the Finish button on the order overview page.
     * Waits for the confirmation message to appear before returning.
     */
    public void finishOrder() {
        checkoutOverviewPage.finishOrder();
        page.waitForLoadState();
        page.waitForSelector(".complete-header"); // Wait for the confirmation header to render
    }

    /**
     * Returns the confirmation message text shown after a successful order.
     *
     * @return The confirmation text (e.g. "Thank you for your order!")
     */
    public String getConfirmationMessage() {
        return confirmationPage.getConfirmationText().trim();
    }

    /**
     * Executes the complete checkout journey in one call:
     * open cart → proceed → fill form → finish order.
     *
     * Used by tests that only need to assert the final confirmation
     * and do not need to verify intermediate steps.
     */
    public void completeFullCheckout() {
        openCart();
        proceedToCheckout();
        fillCheckoutInformation();
        finishOrder();
    }
}