package workflows;

import com.microsoft.playwright.Page;
import data.UserData;
import pages.LoginPage;

/**
 * AuthWorkflow encapsulates all authentication-related user actions.
 *
 * This is the workflow layer — it sits above the Page Objects and
 * below the test classes. A workflow method represents a complete
 * user intention ("log in as a standard user") rather than individual
 * clicks and keystrokes.
 *
 * Tests call workflow methods instead of assembling page interactions
 * themselves, which keeps test methods short and intention-revealing.
 */
public class AuthWorkflow {

    private final Page page;
    private final LoginPage loginPage;

    public AuthWorkflow(Page page) {
        this.page = page;
        this.loginPage = new LoginPage(page);
    }

    /**
     * Navigates to the login page and logs in as the standard user.
     * This is the most common setup action — called at the start of
     * any test that requires an authenticated session.
     */
    public void loginAsStandardUser() {
        page.navigate(UserData.BASE_URL);
        page.waitForLoadState(); // Ensure the login page is ready before filling the form
        loginPage.login(UserData.STANDARD_USER, UserData.VALID_PASSWORD);
        page.waitForLoadState(); // Wait for the inventory page to load after login
    }

    /**
     * Attempts to log in with the locked-out user account.
     * Used in negative tests to verify the correct error message is shown.
     */
    public void loginAsLockedOutUser() {
        page.navigate(UserData.BASE_URL);
        page.waitForLoadState();
        loginPage.login(UserData.LOCKED_OUT_USER, UserData.VALID_PASSWORD);
        // No waitForLoadState here — the page does not navigate on a failed login
    }

    /**
     * Attempts to log in with a valid username but incorrect password.
     * Used in negative tests to verify the credential mismatch error message.
     */
    public void loginWithInvalidPassword() {
        page.navigate(UserData.BASE_URL);
        page.waitForLoadState();
        loginPage.login(UserData.STANDARD_USER, UserData.INVALID_PASSWORD);
    }

    /**
     * Logs out of the application by opening the burger menu and clicking Sign Out.
     * Navigates back to the login page after logout.
     */
    public void logout() {
        page.click("#react-burger-menu-btn"); // Open the navigation side menu
        page.waitForSelector("#logout_sidebar_link"); // Wait for the menu to animate open
        page.click("#logout_sidebar_link");           // Click the Sign Out link
        page.waitForLoadState();                      // Wait for the login page to reload
    }

    /**
     * Returns the error message text currently shown on the login page.
     * Used by tests to assert what went wrong after a failed login.
     *
     * @return The visible error message string
     */
    public String getLoginError() {
        return loginPage.getErrorMessage();
    }
}