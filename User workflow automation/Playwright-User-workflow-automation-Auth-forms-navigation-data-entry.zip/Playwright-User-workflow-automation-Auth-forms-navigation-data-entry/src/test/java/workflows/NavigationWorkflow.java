package workflows;

import com.microsoft.playwright.Page;
import data.UserData;

/**
 * NavigationWorkflow encapsulates all navigation actions across the application.
 *
 * Rather than calling page.navigate() or clicking nav elements directly inside
 * tests, all navigation is centralised here. If a URL or nav element changes,
 * only this file needs updating.
 *
 * Each method navigates to a specific section and waits for it to be ready
 * before returning control to the caller.
 */
public class NavigationWorkflow {

    private final Page page;

    public NavigationWorkflow(Page page) {
        this.page = page;
    }

    /**
     * Navigates directly to the inventory (Products) page by URL.
     * Faster than clicking through login when the session is already active.
     */
    public void goToInventory() {
        page.navigate(UserData.INVENTORY_URL);
        page.waitForLoadState();
        page.waitForSelector(".inventory_list"); // Wait for the product grid to appear
    }

    /**
     * Navigates to the cart page by clicking the cart icon in the navigation bar.
     * Mirrors what a real user does rather than jumping directly to the URL.
     */
    public void goToCart() {
        page.click("#shopping_cart_container a"); // Click the cart icon
        page.waitForLoadState();
        page.waitForSelector(".cart_list"); // Wait for the cart item list to be present
    }

    /**
     * Navigates directly to the cart page by URL.
     * Used when tests need to inspect the cart state without simulating the click.
     */
    public void goToCartByUrl() {
        page.navigate(UserData.CART_URL);
        page.waitForLoadState();
    }

    /**
     * Returns the current page URL.
     * Used by navigation tests to assert the correct page was reached.
     *
     * @return The full URL of the current page
     */
    public String getCurrentUrl() {
        return page.url();
    }

    /**
     * Returns the text content of the page title element.
     * Used to confirm which page the user is currently on.
     *
     * @return The visible page title string (e.g. "Products", "Your Cart")
     */
    public String getCurrentPageTitle() {
        return page.textContent(".title").trim();
    }
}