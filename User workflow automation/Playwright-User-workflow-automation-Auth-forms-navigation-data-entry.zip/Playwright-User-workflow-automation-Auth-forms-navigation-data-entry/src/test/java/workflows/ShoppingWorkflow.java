package workflows;

import com.microsoft.playwright.Page;
import pages.InventoryPage;

/**
 * ShoppingWorkflow encapsulates all product browsing and cart management actions.
 *
 * Covers: adding items to the cart, removing items, reading cart state,
 * and verifying the product catalogue loaded correctly.
 *
 * Tests call these methods instead of interacting with InventoryPage directly,
 * keeping test logic at the intention level ("add the backpack to the cart")
 * rather than the interaction level ("click element with id X").
 */
public class ShoppingWorkflow {

    private final Page page;
    private final InventoryPage inventoryPage;

    public ShoppingWorkflow(Page page) {
        this.page = page;
        this.inventoryPage = new InventoryPage(page);
    }

    /**
     * Adds the Sauce Labs Backpack to the cart and waits for
     * the cart badge to appear confirming the item was registered.
     */
    public void addBackpackToCart() {
        inventoryPage.addBackpackToCart();
        page.waitForSelector(".shopping_cart_badge"); // Wait for the badge to update
    }

    /**
     * Adds multiple items to the cart in sequence.
     * Waits after each addition for the cart badge to update
     * before moving to the next item.
     */
    public void addMultipleItemsToCart() {
        page.click("#add-to-cart-sauce-labs-backpack");
        page.waitForSelector(".shopping_cart_badge");

        page.click("#add-to-cart-sauce-labs-bike-light");
        // Wait for the badge to update to 2 before continuing
        page.waitForFunction("() => document.querySelector('.shopping_cart_badge').textContent === '2'");

        page.click("#add-to-cart-sauce-labs-bolt-t-shirt");
        // Wait for badge to update to 3
        page.waitForFunction("() => document.querySelector('.shopping_cart_badge').textContent === '3'");
    }

    /**
     * Returns the current cart item count shown in the badge.
     * Returns "0" if the badge is not present (empty cart).
     *
     * @return Cart item count as a string
     */
    public String getCartCount() {
        if (page.isVisible(".shopping_cart_badge")) {
            return page.textContent(".shopping_cart_badge").trim();
        }
        return "0"; // Badge is absent when the cart is empty
    }

    /**
     * Returns whether the inventory product grid is currently visible.
     * Used to verify the products page loaded successfully.
     */
    public boolean isInventoryLoaded() {
        return page.isVisible(".inventory_list");
    }

    /**
     * Returns the title text of the current page.
     * Used to confirm we are on the Products page after login.
     */
    public String getPageTitle() {
        return inventoryPage.getPageTitle().trim();
    }
}