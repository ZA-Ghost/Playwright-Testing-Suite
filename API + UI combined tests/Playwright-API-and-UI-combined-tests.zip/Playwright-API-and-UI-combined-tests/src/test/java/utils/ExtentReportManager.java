package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

/**
 * ExtentReportManager is a singleton that creates and configures
 * the shared ExtentReports instance for the entire test run.
 *
 * All test classes write their results into one combined HTML report at:
 *   reports/ExtentReport.html
 *
 * The report is opened in any browser — no server required.
 * It includes pass/fail/skip status, browser info, timestamps,
 * failure messages, and embedded failure screenshots.
 */
public class ExtentReportManager {

    private static ExtentReports extent;

    /**
     * Returns the shared ExtentReports instance, creating it on first call.
     *
     * @return The configured ExtentReports singleton
     */
    public static synchronized ExtentReports getInstance() {

        if (extent == null) {

            ExtentSparkReporter spark = new ExtentSparkReporter("reports/ExtentReport.html");
            spark.config().setDocumentTitle("Playwright Automation Report");
            spark.config().setReportName("Workflow Test Results — Trace Viewer Integration");
            spark.config().setTheme(Theme.DARK);
            spark.config().setTimeStampFormat("dd MMM yyyy HH:mm:ss");

            extent = new ExtentReports();
            extent.attachReporter(spark);

            // System info shown in the Environment panel of the report
            extent.setSystemInfo("Project",     "SauceDemo Playwright Suite");
            extent.setSystemInfo("Environment", "QA");
            extent.setSystemInfo("Tester",      "Khwezi");
            extent.setSystemInfo("Framework",   "Playwright + TestNG");
            extent.setSystemInfo("Base URL",    "https://www.saucedemo.com");
        }

        return extent;
    }
}