package utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * TraceUtil manages Playwright trace files.
 *
 * Responsibilities:
 *   - Ensuring the traces output directory exists before a trace is saved
 *   - Opening the Playwright Trace Viewer in the default browser when a test fails
 *
 * Trace files are saved to:
 *   traces/<browserName>/<testMethodName>.zip
 *
 * Opening the viewer:
 *   The Trace Viewer runs via the Playwright CLI bundled inside the playwright JAR.
 *   It opens as a local web server and launches the OS default browser automatically.
 *   The command is equivalent to running:
 *     mvn exec:java -e -D exec.mainClass=com.microsoft.playwright.CLI
 *                      -D exec.args="show-trace traces/chromium/testLogin.zip"
 */
public class TraceUtil {

    /**
     * Ensures the directory structure for a trace file path exists.
     * Creates all missing parent directories if needed.
     *
     * Called by BaseTest before stopping the trace so the save never fails
     * due to a missing directory.
     *
     * @param tracePath The full relative path of the trace file (e.g. "traces/chromium/testLogin.zip")
     */
    public static void ensureDirectoryExists(String tracePath) {
        try {
            File traceFile = new File(tracePath);
            Files.createDirectories(Paths.get(traceFile.getParent()));
        } catch (IOException e) {
            System.err.println("[TraceUtil] Could not create trace directory: " + e.getMessage());
        }
    }

    /**
     * Opens the Playwright Trace Viewer for a given trace file.
     *
     * Launches the Playwright CLI in a background process so the test
     * suite continues running while the viewer opens in the browser.
     *
     * The viewer is only opened on test failure — passing traces are
     * saved to disk for optional manual review but not opened automatically.
     *
     * @param tracePath The path to the .zip trace file to open
     */
    public static void openTraceViewer(String tracePath) {
        File traceFile = new File(tracePath);

        if (!traceFile.exists()) {
            System.err.println("[TraceUtil] Trace file not found, cannot open viewer: " + tracePath);
            return;
        }

        try {
            System.out.println("[TraceUtil] Opening Trace Viewer for: " + tracePath);

            /*
             * Build the command that launches the Playwright Trace Viewer.
             *
             * This uses the Playwright CLI bundled inside the playwright JAR.
             * ProcessBuilder runs it as a detached background process so it
             * does not block the test suite from continuing.
             *
             * Equivalent CLI command:
             *   mvn exec:java -e -D exec.mainClass=com.microsoft.playwright.CLI
             *                    -D exec.args="show-trace <tracePath>"
             */
            ProcessBuilder pb = new ProcessBuilder(
                    "mvn",
                    "exec:java",
                    "-e",
                    "-D", "exec.mainClass=com.microsoft.playwright.CLI",
                    "-D", "exec.args=show-trace " + traceFile.getAbsolutePath()
            );

            pb.redirectErrorStream(true);           // Merge stderr into stdout
            pb.redirectOutput(ProcessBuilder.Redirect.DISCARD); // Suppress viewer output in console
            pb.start();                             // Launch as a background process

        } catch (IOException e) {
            System.err.println("[TraceUtil] Could not launch Trace Viewer: " + e.getMessage());
        }
    }
}