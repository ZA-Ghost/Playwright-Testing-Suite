package utils;

import com.microsoft.playwright.Page;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * ScreenshotUtil captures a full-page PNG screenshot of the current browser state.
 *
 * Called automatically by BaseTest's @AfterMethod when a test fails,
 * so every failure has a visual record of what the browser showed
 * at the exact moment the assertion failed.
 *
 * Screenshots are saved to:
 *   screenshots/<browserName>/<testMethodName>_<timestamp>.png
 *
 * Playwright's setFullPage(true) captures the entire scrollable page,
 * not just the visible viewport — useful for catching off-screen errors.
 *
 * The saved path is returned so PlaywrightListener can embed the
 * screenshot directly in the Extent HTML report.
 */
public class ScreenshotUtil {

    /**
     * Captures a full-page screenshot and saves it to the screenshots directory.
     *
     * @param page       The active Playwright Page to capture
     * @param testName   The name of the failing test method — used in the filename
     * @param browserName The browser being used — used as a subdirectory name
     * @return The relative file path of the saved screenshot
     */
    public static String capture(Page page, String testName, String browserName) {

        // Build timestamped filename to prevent overwrites across runs
        String timestamp  = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
        String directory  = "screenshots/" + browserName;
        String fileName   = testName + "_" + timestamp + ".png";
        String filePath   = directory + "/" + fileName;

        try {
            // Create the directory if it does not already exist
            Files.createDirectories(Paths.get(directory));

            // Capture and save the screenshot
            page.screenshot(new Page.ScreenshotOptions()
                    .setPath(Paths.get(filePath))
                    .setFullPage(true) // Capture the full scrollable page, not just the viewport
            );

            System.out.println("[ScreenshotUtil] Screenshot saved: " + filePath);

        } catch (IOException e) {
            System.err.println("[ScreenshotUtil] Could not save screenshot: " + e.getMessage());
        }

        return filePath;
    }
}