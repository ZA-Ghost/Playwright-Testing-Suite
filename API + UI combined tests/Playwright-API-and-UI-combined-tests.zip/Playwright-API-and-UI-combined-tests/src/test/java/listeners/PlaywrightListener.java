package listeners;

import base.BaseTest;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import utils.ExtentReportManager;

import java.io.File;

/**
 * PlaywrightListener is a TestNG ITestListener that hooks into the test lifecycle
 * and logs every result into the Extent HTML report.
 *
 * Registered in all TestNG XML suite files — no changes to test classes needed.
 *
 * On test failure it also:
 *   - Embeds the failure screenshot in the report
 *   - Logs the path to the trace zip file so it is visible in the report
 *
 * ThreadLocal<ExtentTest> ensures parallel browser runs each get their
 * own report entry and do not overwrite each other.
 */
public class PlaywrightListener implements ITestListener {

    private static final ExtentReports extent = ExtentReportManager.getInstance();

    // One ExtentTest entry per thread — parallel browsers stay isolated
    private static final ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();

    /**
     * Fires when a test method begins.
     * Creates a named entry in the report tagged with the browser.
     */
    @Override
    public void onTestStart(ITestResult result) {
        String browser = result.getTestContext()
                .getCurrentXmlTest()
                .getParameter("browser");
        if (browser == null) browser = "chromium";

        ExtentTest test = extent.createTest(
                result.getMethod().getMethodName(),
                "Browser: <b>" + browser.toUpperCase() + "</b>"
        );

        extentTest.set(test);
    }

    /**
     * Fires when a test method passes.
     * Logs a green PASS label and the trace file path for reference.
     */
    @Override
    public void onTestSuccess(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        String browser  = BaseTest.getBrowserName();
        String tracePath = "traces/" + browser + "/" + testName + ".zip";

        extentTest.get().pass(MarkupHelper.createLabel("PASSED", ExtentColor.GREEN));

        // Log the trace path so testers can open it manually if needed
        if (new File(tracePath).exists()) {
            extentTest.get().info("Trace saved: <code>" + tracePath + "</code>");
        }
    }

    /**
     * Fires when a test method fails.
     * Logs a red FAIL label, the exception, the trace path, and embeds the screenshot.
     */
    @Override
    public void onTestFailure(ITestResult result) {
        String testName  = result.getMethod().getMethodName();
        String browser   = BaseTest.getBrowserName();
        String tracePath = "traces/" + browser + "/" + testName + ".zip";

        extentTest.get().fail(MarkupHelper.createLabel("FAILED", ExtentColor.RED));
        extentTest.get().fail(result.getThrowable()); // Log the full exception and stack trace

        // Log the trace file path — testers can open it with: playwright show-trace <path>
        extentTest.get().info(
                "Trace Viewer: run <code>mvn exec:java -e "
                        + "-D exec.mainClass=com.microsoft.playwright.CLI "
                        + "-D exec.args=\"show-trace " + tracePath + "\"</code>"
        );

        // Find and embed the most recent screenshot for this test and browser
        try {
            File screenshotDir = new File("screenshots/" + browser);
            if (screenshotDir.exists()) {
                File[] files = screenshotDir.listFiles(
                        f -> f.getName().startsWith(testName) && f.getName().endsWith(".png")
                );
                if (files != null && files.length > 0) {
                    // Use the most recently created screenshot file
                    File latest = files[files.length - 1];
                    extentTest.get().addScreenCaptureFromPath(
                            latest.getPath(), "Screenshot at point of failure"
                    );
                }
            }
        } catch (Exception e) {
            extentTest.get().info("Screenshot could not be embedded: " + e.getMessage());
        }
    }

    /**
     * Fires when a test method is skipped.
     * Logs an orange SKIP label.
     */
    @Override
    public void onTestSkipped(ITestResult result) {
        extentTest.get().skip(MarkupHelper.createLabel("SKIPPED", ExtentColor.ORANGE));
    }

    /**
     * Fires after all tests in the suite complete.
     * Flushes all buffered results to the HTML report file.
     * Without flush() the report file will be empty.
     */
    @Override
    public void onFinish(ITestContext context) {
        if (extent != null) {
            extent.flush();
        }
    }
}