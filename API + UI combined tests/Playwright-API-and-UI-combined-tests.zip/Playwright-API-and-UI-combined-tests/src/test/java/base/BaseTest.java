package base;

import com.microsoft.playwright.*;
import org.testng.ITestResult;
import org.testng.annotations.*;
import utils.ScreenshotUtil;
import utils.TraceUtil;

/**
 * BaseTest manages the full Playwright lifecycle and wraps every test
 * method with trace recording.
 *
 * Lifecycle per test run:
 *
 *   @BeforeClass  — create Playwright, launch browser, open context and page
 *   @BeforeMethod — start a new trace for the upcoming test
 *   @AfterMethod  — stop the trace; save it always, open Trace Viewer on failure
 *   @AfterClass   — close page context, browser, and Playwright engine
 *
 * Tracing options:
 *   setScreenshots(true) — capture a screenshot after every action
 *   setSnapshots(true)   — capture a full DOM snapshot after every action
 *   setSources(true)     — embed the Java source file that triggered each action
 *
 * These three options together give Trace Viewer everything it needs to show
 * a full step-by-step playback with before/after DOM and visual diffs.
 */
public class BaseTest {

    // One Page per thread — prevents parallel browser runs from sharing state
    private static final ThreadLocal<Page>            pageThreadLocal    = new ThreadLocal<>();
    private static final ThreadLocal<BrowserContext>  contextThreadLocal = new ThreadLocal<>();

    private Playwright playwright;
    private Browser    browser;

    // Shared browser name — set during setUp, used in trace filenames
    private static final ThreadLocal<String> browserNameThreadLocal = new ThreadLocal<>();

    public static Page getPage() {
        return pageThreadLocal.get();
    }

    public static String getBrowserName() {
        return browserNameThreadLocal.get();
    }

    /**
     * Runs once before any tests in this class.
     * Launches the browser specified in the TestNG XML parameter.
     *
     * @param browserName "chromium", "firefox", or "webkit"
     */
    @BeforeClass
    @Parameters("browser")
    public void setUp(@Optional("chromium") String browserName) {

        browserNameThreadLocal.set(browserName);
        playwright = Playwright.create();

        BrowserType.LaunchOptions launchOptions = new BrowserType.LaunchOptions()
                .setHeadless(false) // Show the browser window during execution
                .setSlowMo(60);     // 60ms between every action for visibility

        browser = switch (browserName.toLowerCase()) {
            case "firefox" -> playwright.firefox().launch(launchOptions);
            case "webkit"  -> playwright.webkit().launch(launchOptions);
            default        -> playwright.chromium().launch(launchOptions);
        };

        BrowserContext context = browser.newContext(
                new Browser.NewContextOptions()
                        .setViewportSize(1366, 768)
        );

        contextThreadLocal.set(context);

        Page page = context.newPage();
        pageThreadLocal.set(page);

        page.navigate("https://www.saucedemo.com/");
        page.waitForLoadState();
    }

    /**
     * Runs before every individual @Test method.
     *
     * Starts a fresh trace for the upcoming test.
     * Each test gets its own trace file so replaying one test
     * does not require scrubbing through an entire suite recording.
     *
     * setScreenshots — screenshot after every Playwright action
     * setSnapshots   — DOM snapshot after every Playwright action
     * setSources     — Java source reference embedded in each step
     */
    @BeforeMethod
    public void startTrace() {
        BrowserContext context = contextThreadLocal.get();
        if (context != null) {
            context.tracing().start(new Tracing.StartOptions()
                    .setScreenshots(true) // Capture a screenshot after every action
                    .setSnapshots(true)   // Capture a full DOM snapshot after every action
                    .setSources(true)     // Embed Java source file references in the trace
            );
        }
    }

    /**
     * Runs after every individual @Test method.
     *
     * Stops the trace and saves it to traces/<browser>/<TestName>.zip.
     *
     * If the test FAILED:
     *   - Saves a PNG screenshot to screenshots/<browser>/<TestName>.png
     *   - Opens the Trace Viewer in the browser automatically via TraceUtil
     *
     * If the test PASSED or SKIPPED:
     *   - The trace zip is still saved for optional manual review
     *   - Trace Viewer is not opened automatically
     *
     * @param result TestNG result object — contains the test name and pass/fail status
     */
    @AfterMethod
    public void stopTrace(ITestResult result) {
        BrowserContext context = contextThreadLocal.get();
        Page           page    = pageThreadLocal.get();

        if (context != null) {
            String testName   = result.getMethod().getMethodName();
            String browser    = getBrowserName();

            // Build the trace output path: traces/<browser>/<testName>.zip
            String tracePath  = "traces/" + browser + "/" + testName + ".zip";

            // Stop the trace and write it to disk
            context.tracing().stop(new Tracing.StopOptions().setPath(
                    java.nio.file.Paths.get(tracePath)
            ));

            // On failure: save a screenshot and open the Trace Viewer
            if (result.getStatus() == ITestResult.FAILURE) {
                if (page != null) {
                    ScreenshotUtil.capture(page, testName, browser);
                }
                TraceUtil.openTraceViewer(tracePath);
            }
        }
    }

    /**
     * Runs once after all tests in this class complete.
     * Closes the browser context, browser, and Playwright engine.
     */
    @AfterClass
    public void tearDown() {
        BrowserContext context = contextThreadLocal.get();
        if (context != null) {
            context.close();
            contextThreadLocal.remove();
        }
        pageThreadLocal.remove();
        browserNameThreadLocal.remove();
        if (browser    != null) browser.close();
        if (playwright != null) playwright.close();
    }
}